export interface PdfProps {
    src: string;
    height?: number;
  }